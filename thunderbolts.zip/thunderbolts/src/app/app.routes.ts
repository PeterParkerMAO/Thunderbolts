import { Route } from '@angular/router';
import { TeamRegistrationComponent } from './components/team-registration/team-registration.component';
import { GameRegistrationComponent } from './components/game-registration/game-registration.component';
import { RankingComponent } from './components/ranking/ranking.component';
import { HomeComponent } from './components/home/home.component';  // Importando a tela inicial

export const appRoutes: Route[] = [
  { path: '', component: HomeComponent }, // Rota para a tela inicial
  { path: 'team-registration', component: TeamRegistrationComponent },
  { path: 'game-registration', component: GameRegistrationComponent },
  { path: 'ranking', component: RankingComponent }
];
