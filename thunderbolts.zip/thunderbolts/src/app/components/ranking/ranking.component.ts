import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';

@Component({
  selector: 'app-ranking',
  template: `
    <table mat-table [dataSource]="ranking">
      <ng-container matColumnDef="nome">
        <th mat-header-cell *matHeaderCellDef> Time </th>
        <td mat-cell *matCellDef="let element"> {{element.nome}} </td>
      </ng-container>
      <ng-container matColumnDef="pontos">
        <th mat-header-cell *matHeaderCellDef> Pontos </th>
        <td mat-cell *matCellDef="let element"> {{element.pontos}} </td>
      </ng-container>
      <ng-container matColumnDef="saldo_gols">
        <th mat-header-cell *matHeaderCellDef> Saldo de Gols </th>
        <td mat-cell *matCellDef="let element"> {{element.saldo_gols}} </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
      <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
    </table>
  `,
  standalone: true,
  imports: [CommonModule, MatTableModule]
})
export class RankingComponent {
  ranking: any[] = [];
  displayedColumns: string[] = ['nome', 'pontos', 'saldo_gols'];

  constructor(private http: HttpClient) {
    this.loadRanking();
  }

  loadRanking() {
    this.http.get('http://localhost:3000/ranking').subscribe(
      (response: any) => {
        this.ranking = response;
      },
      (error) => {
        console.error('Erro ao carregar ranking:', error);
      }
    );
  }
}
