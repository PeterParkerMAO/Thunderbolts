import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-team-registration',
  template: `
    <mat-form-field appearance="outline" class="w-full">
      <mat-label>Nome do Time</mat-label>
      <input matInput [(ngModel)]="teamName">
    </mat-form-field>
    <button mat-raised-button color="primary" (click)="addTeam()">Cadastrar Time</button>
  `,
  standalone: true,
  imports: [CommonModule, FormsModule, MatButtonModule, MatFormFieldModule, MatInputModule] // Adicionar FormsModule aqui
})
export class TeamRegistrationComponent {
  teamName: string = '';

  constructor(private http: HttpClient) {}

  addTeam() {
    this.http.post('http://localhost:3000/times', { nome: this.teamName }).subscribe(
      (response) => {
        console.log('Time cadastrado:', response);
      },
      (error) => {
        console.error('Erro ao cadastrar time:', error);
      }
    );
  }
}
