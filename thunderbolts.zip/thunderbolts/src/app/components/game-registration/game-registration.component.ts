import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-game-registration',
  template: `
    <mat-form-field appearance="outline" class="w-full">
      <mat-label>Time 1</mat-label>
      <input matInput [(ngModel)]="time1Id">
    </mat-form-field>

    <mat-form-field appearance="outline" class="w-full">
      <mat-label>Time 2</mat-label>
      <input matInput [(ngModel)]="time2Id">
    </mat-form-field>

    <mat-form-field appearance="outline" class="w-full">
      <mat-label>Placar Time 1</mat-label>
      <input matInput [(ngModel)]="placarTime1">
    </mat-form-field>

    <mat-form-field appearance="outline" class="w-full">
      <mat-label>Placar Time 2</mat-label>
      <input matInput [(ngModel)]="placarTime2">
    </mat-form-field>

    <button mat-raised-button color="primary" (click)="addGame()">Cadastrar Jogo</button>
  `,
  standalone: true,
  imports: [CommonModule, FormsModule, MatButtonModule, MatFormFieldModule, MatInputModule] // Adicionar FormsModule aqui
})
export class GameRegistrationComponent {
  time1Id: number = 0;
  time2Id: number = 0;
  placarTime1: number = 0;
  placarTime2: number = 0;

  constructor(private http: HttpClient) {}

  addGame() {
    this.http.post('http://localhost:3000/jogos', {
      time1_id: this.time1Id,
      time2_id: this.time2Id,
      placar_time1: this.placarTime1,
      placar_time2: this.placarTime2
    }).subscribe(
      (response) => {
        console.log('Jogo cadastrado:', response);
      },
      (error) => {
        console.error('Erro ao cadastrar jogo:', error);
      }
    );
  }
}
